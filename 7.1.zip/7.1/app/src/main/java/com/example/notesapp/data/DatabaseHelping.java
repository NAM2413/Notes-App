package com.example.notesapp.data;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import com.example.notesapp.model.Note;
import com.example.notesapp.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelping extends SQLiteOpenHelper
{
    public DatabaseHelping(@Nullable Context context)
    {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

//    public DatabaseHelping (@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version, @Nullable DatabaseErrorHandler errorHandler)
//    {
//        super(context, name, factory, version, errorHandler);
//    }

    @Override
    public void onCreate(SQLiteDatabase DB)
    {
        String CREATE_NOTE_TABLE = "CREATE TABLE " + Util.TABLE_NAMES + "(" + Util.NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.Notes_Name + " TEXT , " + Util.Notes_Content + " TEXT)";

        DB.execSQL(CREATE_NOTE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion)
    {

        String DROP_NOTE_TABLE = "DROP TABLE IF EXISTS";
        DB.execSQL(DROP_NOTE_TABLE, new String[]{Util.TABLE_NAMES});

        onCreate(DB);

    }

    public long insertNote (Note note)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.Notes_Name, note.getName());
        contentValues.put(Util.Notes_Content, note.getContent());
        long newRowId = DB.insert(Util.TABLE_NAMES, null, contentValues);
        DB.close(); //to prevent memory leaks.
        return newRowId;
    }

    public List<Note> fetchNotes()
    {
        SQLiteDatabase DB = this.getReadableDatabase();
        List<Note> note_list = new ArrayList<>();
        Cursor cursor = DB.rawQuery("SELECT * FROM " + Util.TABLE_NAMES, null);

        if (cursor.moveToFirst())
        {
            while (!cursor.isAfterLast())
            {
                String Notes_Name = cursor.getString(cursor.getColumnIndex(Util.Notes_Name));
                String Notes_Content = cursor.getString(cursor.getColumnIndex(Util.Notes_Content));
                note_list.add(new Note(Notes_Name, Notes_Content));
                cursor.moveToNext();
            }
        }
        DB.close();
        return note_list;
    }

    public Note fetchNote(String name, String content)
    {
        SQLiteDatabase DB = this.getReadableDatabase();
        Note note;
        //Cursor cursor = DB.rawQuery("SELECT * FROM " + Util.TABLE_NAMES + " WHERE " + Util.Notes_Name + "=" + name + "AND " + Util.Notes_Content + "=" + content, null);
        Cursor cursor = DB.query(Util.TABLE_NAMES, new String[]{Util.NOTE_ID}, Util.Notes_Name + "=? and " + Util.Notes_Content + "=?",
            new String[] {name, content}, null, null, null);
        String Notes_Name = cursor.getString(cursor.getColumnIndex(Util.Notes_Name));
        String Notes_Content = cursor.getString(cursor.getColumnIndex(Util.Notes_Content));
        note = new Note(Notes_Name, Notes_Content);
        DB.close();
        return note;
    }

    public void deleteNote (Note note)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.delete(Util.TABLE_NAMES, Util.Notes_Name + "=?", new String[]{String.valueOf(note.getName())}); //delete note where the id is the one in the parameter
    }

    //updates the name and content and returns the passed in id.
    public boolean updateNote (Note note)
    {
        SQLiteDatabase DB = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.Notes_Name, note.getName());
        contentValues.put(Util.Notes_Content, note.getContent());
        DB.update(Util.TABLE_NAMES, contentValues, Util.Notes_Name + "=?", new String[]{String.valueOf(note.getName())});
        DB.close();
        return true;
    }

}
