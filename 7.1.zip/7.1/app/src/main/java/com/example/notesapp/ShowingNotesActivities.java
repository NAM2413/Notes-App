package com.example.notesapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.notesapp.data.DatabaseHelping;
import com.example.notesapp.model.Note;
import com.example.notesapp.model.NotesAdapting;

import java.util.List;

public class ShowingNotesActivities extends AppCompatActivity implements NotesAdapting.OnRowClickListener
{
    private RecyclerView Notes_Recycling;
    private NotesAdapting NotesAdapting;
    private List<Note> Notes_Listing;

//    ListView usersListView ;
//
//    ArrayList<String> Notes_Listing;
//    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_noting);

//        usersListView = findViewById(R.id.usersListView);
//        userArrayList = new ArrayList<>();
//        DatabaseHelping  DB = new DatabaseHelping (ShowingNotesActivities.this);
//
//        List<Note> NotesLists = DB.fetchNotes();
//        for (Note note :NotesLists)
//        {
//            Notes_Listing.add(note.getName());
//        }
//
//        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Notes_Listing);
//        usersListView.setAdapter(adapter);

        DatabaseHelping DB = new DatabaseHelping(this);
        Notes_Listing = DB.fetchNotes();

        Notes_Recycling = findViewById(R.id.notesRecycler);
        NotesAdapting = new NotesAdapting(Notes_Listing, ShowingNotesActivities.this.getApplicationContext(), this);
        Notes_Recycling.setAdapter(NotesAdapting);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        Notes_Recycling.setLayoutManager(layoutManager);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
    }

    @Override
    public void onItemClick(int position)
    {
        Intent intent = new Intent(ShowingNotesActivities.this, UpdatingNotesActivities.class);
        intent.putExtra("current_Notes_Name", Notes_Listing.get(position).getName());
        intent.putExtra("current_Notes_Content", Notes_Listing.get(position).getContent());
        startActivity(intent);
        finish();
    }
}
