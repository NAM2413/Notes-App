package com.example.notesapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.notesapp.data.DatabaseHelping;
import com.example.notesapp.model.Note;

class CreatingNotesActivities extends AppCompatActivity
{

    DatabaseHelping DB;
    Button button_done;
    EditText editText_name, editText_content;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creating_noting);

        DB = new DatabaseHelping(this);

        button_done = (Button)findViewById(R.id.buttonUpdate);
        editText_name = findViewById(R.id.updateName);
        editText_content = findViewById(R.id.updateContent);
    }

    public void onClickDone(View v)
    {
        String name = editText_name.getText().toString();
        String content = editText_content.getText().toString();

        long result = DB.insertNote(new Note(name, content));
        if (result != 0)
        {
            Toast.makeText(CreatingNotesActivities.this, "Complete!", Toast.LENGTH_SHORT).show();
            finish();
        }
        else
        {
            Toast.makeText(CreatingNotesActivities.this, "Oops. Something went wrong :(", Toast.LENGTH_SHORT).show();
        }
    }

}
