package com.example.notesapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.notesapp.data.DatabaseHelping;
import com.example.notesapp.model.Note;

public class UpdatingNotesActivities extends AppCompatActivity
{

    DatabaseHelping DB;
    String Notes_Name;
    String Notes_Content;
    Note note;
    String Updated_Names;
    String Updated_Contents;

    EditText Name_Updating;
    EditText Content_Updating;
    Button Updating_Button;
    Button Deleting_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updating_noting);

        DB = new DatabaseHelping(this);
        Name_Updating = findViewById(R.id.updateName);
        Content_Updating = findViewById(R.id.updateContent);
        Updating_Button = (Button)findViewById(R.id.buttonUpdate);
        Deleting_Button = (Button)findViewById(R.id.buttonDelete);

        Notes_Name = getIntent().getStringExtra("current_Notes_Name");
        Notes_Content = getIntent().getStringExtra("current_Notes_Content");
        Toast.makeText(UpdatingNotesActivities.this, "Notes_Name" + Notes_Name, Toast.LENGTH_SHORT).show();
        note = new Note(Notes_Name, Notes_Content);

        Name_Updating.setText(note.getName());
        Content_Updating.setText(note.getContent());
    }

    public void onClickUpdate(View v)
    {

        EditText Updated_Names_edit = findViewById(R.id.updateName);
        EditText Updated_Contents_edit = findViewById(R.id.updateContent);
        Updated_Names = Updated_Names_edit.getText().toString();
        Updated_Contents = Updated_Contents_edit.getText().toString();
        Note updated_note = new Note(Updated_Names, Updated_Contents);

        boolean done = DB.updateNote(updated_note);

        if (done == true)
        {
            Toast.makeText(UpdatingNotesActivities.this, "Success!", Toast.LENGTH_SHORT).show();
            finish();
        }
        else
        {
            Toast.makeText(UpdatingNotesActivities.this, "  Uh Oh, Something Went Wrong ", Toast.LENGTH_SHORT).show();
        }

    }

    public void onClickDelete(View v)
    {
        DB.deleteNote(note);
        //Toast.makeText(UpdatingNotesActivities.this, "Deleted!" + note.getId(), Toast.LENGTH_SHORT).show();
        finish();
    }
}
