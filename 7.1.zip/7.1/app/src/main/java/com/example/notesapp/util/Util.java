package com.example.notesapp.util;

public class Util {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "note_DB";
    public static final String TABLE_NAMES = "notes";

    public static final String NOTE_ID = "note_id";
    public static final String Notes_Name = "Notes_Name";
    public static final String Notes_Content = "Notes_Content";
}

