package com.example.notesapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity
{

    Button Creating_Button;
    Button Showing_Button;
    ImageView Home_Image;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Creating_Button = (Button) findViewById(R.id.CreatingButton);
        Showing_Button = (Button) findViewById(R.id.ShowButton);
        Home_Image = (ImageView) findViewById(R.id.HomeImage);
    }

    public void onClickCreate(View v)
    {
        Intent intent = new Intent(MainActivity.this, CreatingNotesActivities.class);
        startActivity(intent);  // Start CreatingNotesActivities
    }

    public void onClickShow(View v)
    {
        Intent intent = new Intent(MainActivity.this, ShowingNotesActivities.class);
        startActivity(intent);  // Start CreatingNotesActivities
    }
}
